import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/report_card.dart';
import '../widgets/status_badge.dart';
import 'report_detail_screen.dart';

/// Data sementara supaya kartu dan detail bisa tampil.
/// Nanti diganti dengan model + data dummy sendiri (langkah b).
class _SampleReport {
  const _SampleReport({
    required this.id,
    required this.status,
    required this.coordinates,
    required this.address,
    required this.time,
    required this.imageUrl,
    required this.type,
    required this.severity,
    required this.notes,
  });

  final String id;
  final ReportStatus status;
  final String coordinates;
  final String address;
  final String time;
  final String imageUrl;
  final String type;
  final int severity;
  final String notes;
}

const _samples = [
  _SampleReport(
    id: 'RPT-001',
    status: ReportStatus.draft,
    coordinates: 'Lat: -0.9471, Long: 100.3543',
    address: 'Jl. Sudirman No.12, Padang',
    time: 'Hari ini, 10:42 WIB',
    imageUrl:
        'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&h=400&fit=crop&auto=format',
    type: 'Lubang',
    severity: 2,
    notes:
        'Lubang cukup dalam, berbahaya saat hujan karena tidak terlihat. Diameter sekitar 50cm.',
  ),
  _SampleReport(
    id: 'RPT-002',
    status: ReportStatus.failed,
    coordinates: 'Lat: -0.9512, Long: 100.3601',
    address: 'Jl. Ahmad Yani KM 3, Padang',
    time: 'Kemarin, 14:20 WIB',
    imageUrl:
        'https://images.unsplash.com/photo-1621501503460-705284897f1a?w=600&h=400&fit=crop&auto=format',
    type: 'Retak',
    severity: 1,
    notes: 'Retakan memanjang sepanjang sekitar 2 meter di sisi kiri jalan.',
  ),
  _SampleReport(
    id: 'RPT-003',
    status: ReportStatus.synced,
    coordinates: 'Lat: -0.9388, Long: 100.3455',
    address: 'Jl. Khatib Sulaiman No.5, Padang',
    time: '12 Mei, 09:15 WIB',
    imageUrl:
        'https://images.unsplash.com/photo-1534346853755-e7bb523efec7?w=600&h=400&fit=crop&auto=format',
    type: 'Amblas',
    severity: 3,
    notes: 'Jalan amblas cukup parah, truk besar tidak dapat melewati area ini.',
  ),
];

class DashboardTab extends StatelessWidget {
  const DashboardTab({super.key, required this.isOnline});

  final bool isOnline;

  void _openDetail(BuildContext context, _SampleReport r) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ReportDetailScreen(
          id: r.id,
          status: r.status,
          severity: r.severity,
          type: r.type,
          time: r.time,
          address: r.address,
          coordinates: r.coordinates,
          imageUrl: r.imageUrl,
          notes: r.notes,
          isOnline: isOnline,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 96),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _MetricsCard(),
          const SizedBox(height: 24),
          const Text(
            'Riwayat Laporan',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 16),
          for (final r in _samples) ...[
            ReportCard(
              location: r.coordinates,
              time: r.time,
              imageUrl: r.imageUrl,
              status: r.status,
              onTap: () => _openDetail(context, r),
            ),
            const SizedBox(height: 16),
          ],
        ],
      ),
    );
  }
}

class _MetricsCard extends StatelessWidget {
  const _MetricsCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const _Metric(value: '3', label: 'Menunggu\nSinyal', color: AppColors.warning),
          Container(width: 1, height: 40, color: AppColors.border),
          const _Metric(value: '12', label: 'Terkirim', color: AppColors.success),
          Container(width: 1, height: 40, color: AppColors.border),
          const _Metric(value: '1', label: 'Gagal\nKirim', color: AppColors.danger),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.value, required this.label, required this.color});

  final String value;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: color),
        ),
        const SizedBox(height: 4),
        Text(
          label.toUpperCase(),
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
            color: AppColors.textMuted,
          ),
        ),
      ],
    );
  }
}
